CREATE PROCEDURE addBalance(IN orderID INT(10))
  BEGIN

	#select @divamount:=a.amount,@divpercent:=a.percentage from ydx_dividend_types a, ydx_users b where a.id=b.dividend_type_id and b.id=userID;
    
    #set @divdentAmount:=realPay*@divpercent+@divamount;
    
    #IF  not exists (select order_id from ydx_user_balances where order_id=orderID) 
    #then
    #     insert into ydx_user_balances (order_id,user_id,franchisee_id,balance,balance_month,clearable,closed,description)
     #values (orderID,userID,franchiseeID,@divdentAmount,now(),0,0,vDescription);
    
    #end if;
    
    
    
    #set balance=RAND();
SELECT * FROM ydx_orders;
    
END;
