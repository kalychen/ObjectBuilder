CREATE PROCEDURE setDividend(IN orderID INT(10), OUT isSuccess INT(10))
  BEGIN

         
	set isSuccess=0;
    set @driverID=0;
    set @serviceID=0;
    set @creatorID=0;
    set @franchiseeID=0;
    set @realPrice=0;
    set @divamount=0;
    set @divpercent=0;
    set @dividendAmount=0;
    set @uName='';
    
	select @driverID:=driver_id,@serviceID:=service_place_id,@creatorID:=order_creator_id,@franchiseeID:=franchisee_id, @realPrice:=real_price 
    from ydx_orders where id=orderID;
 
 if @realPrice>0 then
	if  @driverID<>NULL or @driverID >0  then   -- 司机提成
    
		if exists (select distinct @uID:=a.id, @uName:=concat(a.last_name,a.first_name), @divamount:=c.amount,@divpercent:=c.percentage 
					from ydx_users a, ydx_orders b, ydx_dividend_types c , ydx_driver_info d
					where a.id=d.user_id and d.id=b.driver_id and a.dividend_type_id=c.id and b.driver_id=@driverID) 
        then
			set @dividendAmount:=@realPrice*@divpercent+@divamount;
			IF  not exists (select order_id from ydx_user_balances where order_id=orderID and user_id=@uID ) then  
					insert into ydx_user_balances (order_id,user_id,franchisee_id,balance,balance_month,clearable,closed,description)
					values (orderID,@uID,NULL,@dividendAmount,now(),0,0,concat('司机',@uName));
					set isSuccess:=isSuccess+1;
			else
				update ydx_user_balances set balance=@dividendAmount,balance_month=now(),description=concat('司机',@uName,'佣金有变更')
                where order_id=orderID and user_id=@uID;
				set isSuccess:=isSuccess+10;
			end if;
		end if;
	end if;
    
	if @franchiseeID<>NULL or @franchiseeID>0 then   -- 代理商提成
    
		if exists (
		select distinct @uID:=a.id,@uName:=a.org_name, @divamount:=c.amount,@divpercent:=c.percentage 
        from ydx_franchisees a, ydx_orders b, ydx_dividend_types c
        where a.id=b.franchisee_id and a.dividend_type_id=c.id and b.franchisee_id=@franchiseeID
        ) 
        then
			set @dividendAmount:=@realPrice*@divpercent+@divamount;
			IF  not exists (select order_id from ydx_user_balances where order_id=orderID and franchisee_id=@uID) then  
				insert into ydx_user_balances (order_id,user_id,franchisee_id,balance,balance_month,clearable,closed,description)
				values (orderID,NULL,@uID,@dividendAmount,now(),0,0,concat('代理商',@uName));
				set isSuccess:=isSuccess+100;

			else
				update ydx_user_balances set balance=@dividendAmount,balance_month=now(),description=concat('代理商',@uName,'佣金有变更')
                where order_id=orderID and franchisee_id=@uID;   
				set isSuccess:=isSuccess+1000;
			end if;
		end if;
	end if;   
    
    
    if @serviceID<>NULL or @serviceID >0  then   -- 调度员提成
    
		 call addDivdidentForDispatcher(orderID,@serviceID,@realPrice,@flag);
		 if @flag>0 then  
			set isSuccess:=isSuccess+@flag; 
		 end if;
	end if;
    /*
    
		if exists (
			select distinct @uID:=a.id, @uName:=concat(a.last_name,a.first_name), @divamount:=c.amount,@divpercent:=c.percentage 
			from ydx_users a, ydx_orders b, ydx_dividend_types c, ydx_dispatcher_info d
			where a.id=d.user_id and d.id=b.order_creator_id and a.dividend_type_id=c.id and b.service_place_id=@serviceID
        ) 
        then
            set @dividendAmount:=@realPrice*@divpercent+@divamount;
			IF  not exists (select order_id from ydx_user_balances where order_id=orderID and user_id=@uID) then  
				insert into ydx_user_balances (order_id,user_id,franchisee_id,balance,balance_month,clearable,closed,description)
				values (orderID,@uID,NULL,@dividendAmount,now(),0,0,concat('调试员/制单人',@uName));
				set isSuccess:=isSuccess+4;

			else
				update ydx_user_balances set balance=@dividendAmount,balance_month=now(),description=concat('调试员/制单人',@uName,'佣金有变更')
                where order_id=orderID and user_id=@uID;
				set isSuccess:=isSuccess+40;
			end if;
		end if;
	end if;
    */
    
    


   /* 
    if not exists (select distinct order_id from ydx_user_balances where order_id=orderID) 
    then
		set isSuccess=0;
    else 
		set isSuccess=1;
	end if;
*/

end if;
END;
