CREATE PROCEDURE getPrice(
  IN  orderTypeId INT(10), IN `IN`servicePlaceId`` INT (10), IN `IN`pricingCodeId`` INT (10), IN `IN`promotionCodeId`` INT (10), IN `IN`distance`` DOUBLE (22), IN `IN`departTime`` TIMESTAMP (19), IN `IN`charterType`` INT (10), IN `IN`charterCount`` DOUBLE (22), IN `IN`airportId`` INT (10), IN `IN`airportType`` INT (10), IN `IN`pricingRegion`` INT (10),
  OUT oriPrice    DOUBLE(22), OUT proPrice DOUBLE(22))
  BEGIN
 -- DECLARE vPrice VARCHAR(64) DEFAULT '';
declare dTripRate DECIMAL(7,6) default 0.000000;
set @amountoff=0, @percentoff=100;
set oriPrice:=0,proPrice:=0;


IF orderTypeId>0 THEN
 		CASE  orderTypeId
			WHEN 1 THEN  -- 1:里程订单
				set @baseprice=0;
				set @basedistance=0;
				set @priceperkm=0;
				set @distancecompensatorythreshold=0;
				set @returntripdivider=0;
				set @returntrippower=0;
				set @returntripA=0;
				set @returntripB=0;
				set @returntripC=0;
				select @baseprice:=a.base_price,@basedistance:=a.base_distance,@priceperkm:=a.price_per_km ,
                @distancecompensatorythreshold:=a.distance_compensatory_threshold, @returntripdivider:=a.return_trip_compensatory_divider,
                @returntrippower:=a.return_trip_compensatory_power,@returntripA:=a.return_trip_compensatory_coefficient_a,
                @returntripB:= a.return_trip_compensatory_coefficient_b,@returntripC:=a.return_trip_compensatory_coefficient_c  
                FROM ydx_pricing_algorithms a, ydx_pricing_codes_algorithms b  
                where a.id=b.pricing_algorithm_id and b.pricing_code_id=pricingCodeId and  b.order_type_id=orderTypeId ; 

				if distance <= @basedistance then
					SET oriPrice=@baseprice;
				else
					if 	 distance <= @distancecompensatorythreshold then
                        select distance, @returntripA,@returntripB,@returntripC,@returntripdivider,@returntrippower;
						SET dTripRate =  power(distance/@returntripdivider,@returntrippower)*@returntripA+@returntripB*(distance/@returntripdivider)+@returntripC;
					else
						SET dTripRate=0;
					end if;

					SET oriPrice:=(@baseprice+@priceperkm*(distance-@basedistance))*(1+dTripRate) ;
				 end if;
                 
				-- 里程优惠
				select @amountoff:=a.amount_off_for_regular,@percentoff:=a.percent_off_for_regular 
				from ydx_promotion_algorithms a, ydx_promotion_codes_algorithms b
				where a.available=1 and a.id=b.promotion_algorithm_id and b.promotion_code_id= promotionCodeId 
				and b.order_type_id=1;
             


			WHEN 2 THEN -- 2：接送机订单
				set @myAirportPrice=0;
				if airportId <6 then
					set airportId=1;
				else
					set airportId=6;
				end if;
                select @myAirportPrice:=a.fixed_price
                FROM ydx_pricing_algorithms a, ydx_pricing_codes_algorithms b 
                where a.id=b.pricing_algorithm_id and b.pricing_code_id=pricingCodeId 
                and  b.order_type_id=orderTypeId 	and b.city_district_id = pricingRegion and b.airport_id=airportId ; 

				set  oriPrice=@myAirportPrice;
                
				-- 接送机优惠
				select @amountoff:=a.amount_off_for_airport,@percentoff:=a.percent_off_for_airport 
				from ydx_promotion_algorithms a, ydx_promotion_codes_algorithms b
				where a.available=1 and a.id=b.promotion_algorithm_id and b.promotion_code_id= promotionCodeId 
				and b.order_type_id=2;


			WHEN 3 THEN -- 3：包车订单
				if charterType=0 then  -- 半天包
					set @halfdayPrice=0;
                    set @halfKmIncluded=0;
                    set @extraPerKm=0;
                    set @extraPerHour=0;
                    
					select @halfdayPrice:=a.halfday_charter_price,@halfKmIncluded:=a.halfday_charter_km_included,
                    @extraPerKm:=a.charter_extra_per_km,  @extraPerHour:=charter_extra_per_hour 
                    FROM ydx_pricing_algorithms a, ydx_pricing_codes_algorithms b 
                    where a.id=b.pricing_algorithm_id and b.pricing_code_id=pricingCodeId and  b.order_type_id=orderTypeId and b.charter_type=0; 
                   
                    SET oriPrice= @halfdayPrice;
                    /* set @extraKm= distance-@halfKmIncluded;
                    set @extraTime= round((FROM_UNIXTIME(departTime)-NOW())/60)-240; -- 半天4小时240分钟
                    
                    if @extraKm>0 then -- 有超里程
                      set oriPrice:=oriPrice+ @extraKm*@extraPerKm;
                    end if;
                    if @extraTime>0 then  -- 有超时间
						set oriPrice:= oriPrice+ @extraPerHour*round(@extraTime/60) ; 
					end if; */
                
                elseif charterType=1 then -- 全天包车
					set @fulldayPrice=0;
                    set @fulldayKmIncluded=0;
                    set @extraPerKm=0;
                    set @extraPerHour=0;
                    
					select	a.id,@fulldayPrice:=a.fullday_charter_price, 
                    @fulldayKmIncluded:=a.fullday_charter_km_included,@extraPerKm:=a.charter_extra_per_km,  
                    @extraPerHour:=charter_extra_per_hour 
                    FROM ydx_pricing_algorithms a, ydx_pricing_codes_algorithms b
                    where a.id=b.pricing_algorithm_id and b.pricing_code_id=pricingCodeId 
                    and  b.order_type_id=orderTypeId and b.charter_type=1 ; 
                    
                    SET oriPrice= @fulldayPrice*charterCount;
                    /*set @extraKm= distance-@fulldayKmIncluded*charterCount;
                    set @extraTime= round((FROM_UNIXTIME(departTime)-NOW())/60)-480*charterCount; -- 全天8小时 480分钟
					select oriPrice;
                    if @extraKm>0 then -- 有超里程
                     set oriPrice=oriPrice+ @extraKm*@extraPerKm;
                    end if;
                    if @extraTime>0 then  -- 有超时间
						set oriPrice:= oriPrice+ @extraPerHour*round(@extraTime/60) ;
					end if; */
                
                    
				elseif charterType=2 then -- 按小时包车
					set @hourPrice=0;
                    set @hourKmIncluded=0;
                    set @extraPerKm=0;
                    set @extraPerHour=0;
                    
					select @hourPrice:=a.hourly_charter_price,@hourKmIncluded:=a.hourly_charter_km_included,
                    @extraPerKm:=a.charter_extra_per_km,  @extraPerHour:=charter_extra_per_hour 
                    FROM ydx_pricing_algorithms a, ydx_pricing_codes_algorithms b
                    where a.id=b.pricing_algorithm_id and b.pricing_code_id=pricingCodeId 
                    and  b.order_type_id=orderTypeId and b.charter_type=2; 
                    
					SET oriPrice= @hourPrice*charterCount;
                   /* set @extraKm= distance-@hourKmIncluded*charterCount;
                    
                    set @extraTime= round((FROM_UNIXTIME(departTime)-NOW())/60)-60*charterCount; 
                    
					if @extraKm>0 then -- 有超里程
                     set oriPrice:=oriPrice+ @extraKm*@extraPerKm;
                    end if;
                    if @extraTime>0 then  -- 有超时间
						set oriPrice:= oriPrice+ @extraPerHour*round(@extraTime/60) ;
					end if; */
                 else
					SET oriPrice=0,proPrice=0;
				end if;
                
				-- 包车优惠
				select @amountoff:=a.amount_off_for_charter,@percentoff:=a.percent_off_for_charter 
				from ydx_promotion_algorithms a, ydx_promotion_codes_algorithms b
				where a.available=1 and a.id=b.promotion_algorithm_id and b.promotion_code_id= promotionCodeId 
				and b.order_type_id=3;


			ELSE  -- 其它
				SET oriPrice=0;

		END CASE;
 END IF;
 
		-- set promotion
        SET proPrice=oriPrice*(1-@percentoff)-@amountoff;



 --   select dTripRate,@returnTripRate, oriPrice,proPrice;
-- 结果取5的整数倍。
/*
		SET @temp1:= floor(round(oriPrice) div 5), @temp2:=mod(round(oriPrice),5);
		if @temp2<3 THEN
			set oriPrice := @temp1*5;
		ELSE
			set oriPrice:= (@temp1+1)*5;
		END if;
		*/

-- select @temp1,@temp2,oriPrice,proPrice;

END;
