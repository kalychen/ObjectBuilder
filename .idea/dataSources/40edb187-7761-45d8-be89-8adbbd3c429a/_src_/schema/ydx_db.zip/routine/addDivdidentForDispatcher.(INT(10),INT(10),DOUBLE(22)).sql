CREATE PROCEDURE addDivdidentForDispatcher(IN  orderID INT(10), IN serviceID INT(10), IN realPay DOUBLE(22),
                                           OUT flag    INT(10))
  BEGIN
	DECLARE iuserID INT default 0;
	DECLARE idividendID int default 0;
    declare done int;
   
    	-- 定义游标
		DECLARE dispatcherCursor CURSOR	FOR	(SELECT b.user_id, a.dividend_type_id 
        FROM ydx_users a, ydx_dispatcher_info b where a.id=b.user_id and b.service_place_id= serviceID and a.dividend_type_id is not NULL ) ;

		-- 定义结束标记
		DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
        set flag=0;
        set @divamount=0;
        set @divpercent=0;
        set @dividendAmount=0;
        set @uName='';
		-- 打开游标
		OPEN dispatcherCursor;
		dispatcherLoop:LOOP   -- 循环
			-- 取游标中的数据
			FETCH dispatcherCursor INTO iuserID,idividendID;
			IF done = 1 THEN
				LEAVE dispatcherLoop;
			END IF;
            -- 主操作
            if idividendID>0 then
				select @divamount:=amount,@divpercent:=percentage  from ydx_dividend_types where id=idividendID;
				set @dividendAmount:=realPay*@divpercent+@divamount;
                select @uName:=concat(last_name,first_name) from ydx_users where id=iuserID;
			
				IF  not exists (select order_id from ydx_user_balances where order_id=orderID and user_id=iuserID) then  
                
					insert into ydx_user_balances (order_id,user_id,franchisee_id,balance,balance_month,clearable,closed,description)
					values (orderID,iuserID,NULL,@dividendAmount,now(),0,0,concat('调度员',@uName));
					set flag:=flag+10000;

				else
					update ydx_user_balances set balance=@dividendAmount,balance_month=now(),description=concat('调度员',@uName,'佣金有变更')
					where order_id=orderID and user_id=iuserID;
					set flag:=flag+100000;
				end if;
			end if; 

		END LOOP dispatcherLoop;  -- 结束循环
		-- 关闭游标
		CLOSE dispatcherCursor;
END;
